from modules.methods import *

if __name__ == "__main__":

    #print(extract_def_from_features('open_rate_recent', duration='3months'))

    #print(extract_def_from_feature_group(fg="5", duration='3months'))

    #print(extract_def_from_features('open_rate_recent', duration='3months'))

    print(extract_def_from_feature_group(fg="4",duration='3months'))

    #print(extract_source_path())

    #features = json.load(
        #open("C:\\Users\\tempsubas\\PycharmProjects\\feature-store-playground\\config\\main_features.dic", 'r'))

    #print(update_fg_with_duration(features,duration=None))




