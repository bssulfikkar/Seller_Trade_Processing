from modules.operations import *


def extract_def_from_features(*fl, duration=None):
    feature_list = []
    for item in fl:
        if item.endswith("recent"):
            feature_list.append(item + duration)
        else:
            feature_list.append(item)
    f = tuple(feature_list)

    ed = ExtractDefinition(duration)
    dependency_list = []
    rf = ""
    f_list = []
    dependency_list = tuple(ed.extract_dependency(dependency_list, *f))
    fg_min, fg_list = ed.extract_fg(*dependency_list, fg=None)
    df = str(ed.features[fg_min].get("source"))
    rf += df
    for i in fg_list:
        rf, f_list = ed.extract_feature(rf, i, *dependency_list, f_list=f_list, df=df)
    f_list += [str(rf)]
    return f_list


def extract_def_from_feature_group(fg, duration=None):
    rf = ""
    f_list = []
    def_list = []
    ed = ExtractDefinition(duration)
    df = str(ed.features[fg].get("source"))
    rf += df
    rf, f_list = ed.extract_feature(rf, fg, f_list=f_list, df=df)
    f_list += [str(rf)]
    for i in f_list:
        def_list.append(ed.replace_params(i))
    return def_list