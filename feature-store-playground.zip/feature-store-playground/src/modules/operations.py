import json
import logging

def extract_source_config(proj):
    source_config = json.load(
        open("C:\\Users\\tempsubas\\PycharmProjects\\feature-store-playground\\config\\source_config.dic", 'r'))
    return source_config[proj]

def extract_source_path(source_config,proj):
    source_path = ''
    source_path += source_config.get('root_folder') + proj + '/' + source_config.get('use_case') + '/' + \
                       source_config.get('env') + '/' + source_config.get('sub_use_case') + '/' + \
                       source_config.get('run_id') + '/' + source_config.get('path')
    return "spark.read.parquet('" + source_path +"')"

def extract_select_cols(value):
    rf = ".select(" + value +")"
    return rf

def extract_select(*col, value):
    rf = ".selectExpr('*',"
    if col is not ():
        for i in value:
            if i in col:
                rf += "'" + value[i] + " as {colname}',".format(colname=i)
    else:
        for i in value:
            rf += "'" + value[i] + " as {colname}',".format(colname=i)
    rf = rf.rstrip(',') + ")"
    return rf


def extract_filter(value):
    return '.filter("{0}")'.format(value)


def extract_agg(*col, value):
    rf = ".agg("
    if col is not ():
        for i in value:
            if i in col:
                rf += value[i] + ".alias('{colname}'),".format(colname=i)
    else:
        for i in value:
            rf += value[i] + ".alias('{colname}'),".format(colname=i)
    rf = rf.rstrip(',') + ")"
    return rf


def extract_group(value):
    return ".groupBy({0})".format(value)


def extract_fill(value, *f):
    fill = ".fillna({"
    if f is not ():
        for key in value:
            if key in f:
                fill += "'{key}':{val},".format(key=key, val=value[key])
    else:
        for key in value:
            fill += "'{key}':{val},".format(key=key, val=value[key])
    fill = fill.rstrip(',') + "})"
    return fill


def update_fg_with_duration(features, duration=None,source_path = None):
    dic_final = {}
    for fg in features:
        temp_dic = {}
        for i in features[fg]:
            if i in ("source") and "<source_path>" in features[fg].get(i):
                features[fg][i] = features[fg].get(i).replace("<source_path>", source_path)
                temp_dic.update({i: features[fg].get(i).replace("<source_path>", source_path)})
            elif i in ("source", "filter", "group","select_cols") and "<duration>" in features[fg].get(i) and duration is not None:
                features[fg][i] = features[fg].get(i).replace("<duration>", duration)
                temp_dic.update({i: features[fg].get(i).replace("<duration>", duration)})
            elif i in ("source", "filter", "group","select_cols"):
                temp_dic.update({i: features[fg].get(i)})
            else:
                dic_temp = {}
                for key in features[fg].get(i):
                    val = features[fg][i].get(key)
                    if duration is not None:
                        if "<duration>" in key:
                            key = key.replace("<duration>", duration)
                        if "<duration>" in str(val):
                            val = val.replace("<duration>", duration)

                    dic_temp.update({key: val})
                temp_dic.update({i: dic_temp})
        dic_final.update({fg: temp_dic})
    return dic_final


class ExtractDefinition:
    def __init__(self, duration=None):
        features = json.load(
            open("C:\\Users\\tempsubas\\PycharmProjects\\feature-store-playground\\config\\main_features.dic", 'r'))
        proj = "personalization"
        self.config=extract_source_config(proj)
        source_path = extract_source_path(self.config,proj)
        if duration:
            self.features = update_fg_with_duration(features['fg'], duration,source_path)
        else:
            self.features = update_fg_with_duration(features['fg'],source_path = source_path)

        self.run_params = features['run_params']

        self.logger = logging.getLogger('extract_def_logger')

    def extract_dependency(self, d_list, *f, fg=None):
        features = self.features
        if f is not ():
            for col in f:
                if col not in d_list:
                    d_list.append(col)
                for key in features:
                    if features[key].get('dependency'):
                        if features[key].get('dependency').get(col):
                            dependency = str(features[key].get('dependency').get(col)).split(',')
                            d_list += list(set(dependency) - set(d_list))
                            for val in dependency:
                                d_list = self.extract_dependency(d_list, val)

        else:
            if features[fg].get('dependency'):
                for key in features[fg].get('dependency'):
                    d_list.append(key)
                    dependency = str(features[fg].get('dependency').get(key)).split(',')
                    d_list += list(set(dependency) - set(d_list))
                    for val in dependency:
                        d_list = self.extract_dependency(d_list, val)
        return d_list

    def extract_fg(self, *f, fg=None, df=None):
        features = self.features
        if f is not None:
            #   if f is not None and fg is None and df is None:
            fg_list = []
            for value in f:
                for key in features.keys():
                    for i in features[key]:
                        if i in ("select", "agg"):
                            for j in features[key].get(i):
                                if value == j:
                                    fg = str(key)
                                    if fg not in fg_list:
                                        fg_list.append(fg)
        if fg_list is not None:
            fg_list1 = sorted(fg_list, reverse=False)
            return fg_list1[0], fg_list1
        else:
            return None, None

    def extract_feature(self, rf, fg, *f, f_list=None, df=None):
        features = self.features
        for i in features[fg]:
            if i == "group":
                max_index = 0
                end_index = 0
                if '.selectExpr(' in rf:
                    max_index = rf.rindex('.selectExpr(')
                if '.agg(' in rf:
                    max_index = max(rf.rindex('.agg('), max_index)
                if max_index > 0:
                    if ').filter' in rf[max_index:]:
                        end_index = rf[max_index:].index(').filter') + 1
                    else:
                        end_index = rf[max_index:].rindex(')') + 1
                index = max_index + end_index
                if index > 0:
                    f_list.append(rf[:index])
                rf += extract_group(str(features[fg].get(i)))
            if i == "agg":
                rf += extract_agg(*f, value=features[fg].get(i))
            if i == "select":
                rf += extract_select(*f, value=features[fg].get(i))
            if i == "fill":
                rf += extract_fill(features[fg].get(i), *f)
            if i == "filter":
                rf += extract_filter(str(features[fg].get(i)))
            if i == "select_cols":
                rf += extract_select_cols(str(features[fg].get(i)))
        return rf, f_list

    def replace_params(self,definition):
        if self.config.get("feature_run_date"):
            feature_run_date = self.config.get("feature_run_date")
        else:
            feature_run_date = 'datetime.datetime.now()'

        return definition\
            .replace("<analysis_start_date>",self.config.get("analysis_start_date")) \
            .replace("<min_trans_date_3months>",self.run_params.get("min_trans_date_3months"))\
            .replace("<min_trans_date_6months>",self.run_params.get("min_trans_date_6months")) \
            .replace("<min_trans_date_9months>", self.run_params.get("min_trans_date_9months")) \
            .replace("<min_trans_date_12months>", self.run_params.get("min_trans_date_12months")) \
            .replace("<feature_run_date>",feature_run_date)